import http.client, io, json, tempfile, threading, time, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import urllib.error
from server import Studio, make_server, DEFAULT_ENDPOINT, RateLimited, UnknownRequest

class StudioTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.studio=Studio(self.temp.name,demo_delay=0)
    def tearDown(self): self.studio.close(); self.temp.cleanup()
    def wait_done(self):
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            state=self.studio.state()
            if not state['running'] and not state['counts']['running']: return state
            time.sleep(.02)
        self.fail('Queue did not finish')
    def test_200_serial_tasks_export(self):
        self.studio.create_project(dict(themes=['Sun','Moon'],count=100,mode='demo'))
        # Wake per completion to avoid artificially long demo waits.
        self.studio.control('start')
        deadline=time.monotonic()+30
        while self.studio.state()['running'] and time.monotonic()<deadline:
            self.studio.wake.set(); time.sleep(.001)
        state=self.wait_done()
        self.assertEqual(state['counts']['completed'],200)
        self.assertEqual(len(state['tasks']),200)
        data=self.studio.export()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            self.assertEqual(len([n for n in z.namelist() if n.endswith('.svg')]),200)
            self.assertIn(b'NOT AI GENERATED', z.read('images/00001.svg'))
    def test_persistence_and_unknown_recovery(self):
        self.studio.create_project(dict(themes=['A'],count=2))
        with self.studio.lock:
            self.studio.db.execute("UPDATE tasks SET status='running' WHERE id=1"); self.studio.db.commit()
        self.studio.close(); self.studio=Studio(self.temp.name,demo_delay=0)
        self.assertEqual(self.studio.state()['counts']['unknown'],1)
        self.assertFalse(self.studio.state()['running'])
        with self.assertRaises(ValueError): self.studio.control('retry',{'ids':[1]})
        self.studio.control('retry',{'ids':[1],'confirmUnknown':True})
        self.assertEqual(self.studio.state()['counts']['pending'],2)
    def test_keys_not_persisted_or_exported(self):
        secret='sk-test-sensitive-123456'
        self.studio.configure(dict(key=secret))
        self.studio.create_project(dict(themes=['A'],count=1))
        self.assertNotIn(secret,json.dumps(self.studio.state()))
        self.assertNotIn(secret.encode(),self.studio.export())
        for path in Path(self.temp.name).glob('*.sqlite3*'): self.assertNotIn(secret.encode(),path.read_bytes())
    def test_provider_pinning_and_custom_confirm(self):
        with self.assertRaises(ValueError): self.studio.configure(dict(providerId='custom',endpoint='https://example.com/images',key='secret'))
        self.studio.configure(dict(providerId='custom',endpoint='https://example.com/images',key='secret',explicitConfirm=True))
        self.studio.create_project(dict(themes=['A'],providerId='custom',mode='openai'))
        self.studio.configure(dict(providerId='custom',endpoint='https://example.org/images',key='other',explicitConfirm=True))
        with self.assertRaises(ValueError): self.studio.control('start')
    def test_sample_and_prompts(self):
        self.studio.create_project(dict(themes=['A'],count=2,prompts=['Exact one','Exact two']))
        self.studio.control('sample'); state=self.wait_done()
        self.assertEqual(state['counts']['completed'],1); self.assertEqual(state['counts']['pending'],1)
        self.assertEqual(state['tasks'][0]['prompt'],'Exact one')
    def test_cancel_preserves_inflight_success(self):
        entered=threading.Event(); release=threading.Event()
        def generate(*args):
            entered.set(); release.wait(3)
            return b'\x89PNG\r\n\x1a\nmock-original', 'png', 'req-test'
        self.studio.configure({'key':'secret'})
        self.studio.create_project(dict(themes=['A'],count=2,mode='openai'))
        with patch.object(self.studio,'_generate',side_effect=generate):
            self.studio.control('start'); self.assertTrue(entered.wait(2))
            self.studio.control('cancel'); release.set(); state=self.wait_done()
        self.assertEqual(state['counts']['completed'],1)
        self.assertEqual(state['counts']['cancelled'],1)
        self.assertEqual(state['tasks'][0]['request_id'],'req-test')
        self.assertTrue(self.studio.image(state['tasks'][0]['id'])[0].endswith(b'mock-original'))
    def test_csv_and_project_export(self):
        self.studio.create_project(dict(name='Test project',themes=['=bad'],count=1,prompts=['Exact prompt']))
        with zipfile.ZipFile(io.BytesIO(self.studio.export())) as archive:
            project=json.loads(archive.read('project.json'))
            self.assertEqual(project['prompts'],['Exact prompt']); self.assertEqual(project['name'],'Test project')
            self.assertIn("'=bad",archive.read('tasks.csv').decode('utf-8-sig'))
    def test_rate_limit_and_ambiguous_responses(self):
        project=dict(model='gpt-image-1.5',size='1024x1024',quality='low')
        task=dict(prompt='test')
        def error(code,error_code):
            return urllib.error.HTTPError(DEFAULT_ENDPOINT,code,'error',{'Retry-After':'2'},io.BytesIO(json.dumps({'error':{'code':error_code}}).encode()))
        with patch('server.urllib.request.build_opener') as mocked:
            mocked.return_value.open.side_effect=error(429,'rate_limit_exceeded')
            with self.assertRaises(RateLimited) as caught: self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
            self.assertEqual(caught.exception.delay,2)
            mocked.return_value.open.side_effect=error(429,'insufficient_quota')
            with self.assertRaises(ValueError) as caught: self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
            self.assertNotIsInstance(caught.exception,RateLimited)
            mocked.return_value.open.side_effect=error(503,'server_error')
            with self.assertRaises(UnknownRequest): self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
            mocked.return_value.open.side_effect=None
            response=mocked.return_value.open.return_value.__enter__.return_value
            response.read.return_value=b'not json'; response.headers={}
            with self.assertRaises(UnknownRequest): self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
    def test_interrupted_read_unknown_and_long_retry_after(self):
        project=dict(model='gpt-image-1.5',size='1024x1024',quality='low'); task=dict(prompt='test')
        with patch('server.urllib.request.build_opener') as mocked:
            response=mocked.return_value.open.return_value.__enter__.return_value
            for error in [http.client.IncompleteRead(b'partial',100),ConnectionResetError('reset')]:
                response.read.side_effect=error
                with self.assertRaises(UnknownRequest): self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
            mocked.return_value.open.side_effect=urllib.error.HTTPError(DEFAULT_ENDPOINT,429,'error',{'Retry-After':'500'},io.BytesIO(b'{"error":{"code":"rate_limit_exceeded"}}'))
            with self.assertRaises(ValueError) as caught: self.studio._generate(task,project,'secret',DEFAULT_ENDPOINT)
            self.assertNotIsInstance(caught.exception,RateLimited)
    def test_bounded_rate_limit_retry(self):
        # Demo dispatch avoids API rate delays while exercising the same queue retry branch.
        self.studio.create_project(dict(themes=['A'],count=1))
        with patch.object(self.studio,'_demo',side_effect=RateLimited(0)):
            self.studio.control('start'); state=self.wait_done()
        self.assertEqual(state['counts']['failed'],1)
        self.assertEqual(state['tasks'][0]['attempts'],3)
        self.assertTrue(state['paused'])
    def test_data_directory_exclusive_lock(self):
        with self.assertRaisesRegex(RuntimeError,'already open'): Studio(self.temp.name)
        self.studio.close(); self.studio=Studio(self.temp.name,demo_delay=0)
        self.assertFalse(self.studio.state()['running'])
    def test_http_security(self):
        static=Path(self.temp.name)/'static'; static.mkdir(); (static/'index.html').write_text('manual page'); (static/'api.html').write_text('api __SESSION_TOKEN__')
        server=make_server(self.studio,static,token='testing-token'); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        def request(path,headers=None,method='GET',body=None):
            c=http.client.HTTPConnection('127.0.0.1',server.server_port); c.request(method,path,body,headers or {}); r=c.getresponse(); result=(r.status,r.read()); c.close(); return result
        try:
            self.assertEqual(request('/')[1],b'manual page')
            self.assertEqual(request('/manual.html')[1],b'manual page')
            self.assertEqual(request('/api.html')[1],b'api testing-token')
            self.assertEqual(request('/api/state')[0],401)
            self.assertEqual(request('/api/state',{'X-Studio-Token':'testing-token'})[0],200)
            self.assertEqual(request('/',{'Host':'evil.example'})[0],403)
            self.assertEqual(request('/',{'Origin':'https://evil.example'})[0],403)
            self.assertEqual(request('/api/state?token=testing-token')[0],401)
            self.assertEqual(request('/../server.py',{'X-Studio-Token':'testing-token'})[0],404)
            self.assertEqual(request('/api/config',{'X-Studio-Token':'testing-token','Content-Type':'text/plain'},'POST','{}')[0],400)
        finally: server.shutdown(); server.server_close(); thread.join()

if __name__=='__main__': unittest.main(verbosity=2)
