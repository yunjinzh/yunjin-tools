@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 server.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3.10 or newer is required. Install from https://www.python.org/downloads/windows/
    echo During installation enable Add Python to PATH.
    pause
    exit /b 1
  )
  python server.py
)
pause
