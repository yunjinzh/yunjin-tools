#!/usr/bin/env python3
"""Local batch image studio. Python 3.10+, standard library only."""
import argparse, base64, csv, datetime, email.utils, html, math, re, io, json, os, secrets, sqlite3, threading, time, urllib.error, urllib.parse, urllib.request, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

DEFAULT_ENDPOINT = 'https://api.openai.com/v1/images/generations'
MAX_BODY = 32 * 1024 * 1024

class RateLimited(ValueError):
    def __init__(self, delay):
        super().__init__('Rate limit reached; bounded retry scheduled.')
        self.delay = delay

class UnknownRequest(ValueError):
    pass

class Studio:
    def __init__(self, directory, demo_delay=0.1):
        self.directory = Path(directory); self.directory.mkdir(parents=True, exist_ok=True)
        self._lockfile = open(self.directory / '.studio.lock','a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                if self._lockfile.seek(0,2) == 0: self._lockfile.write(b'0'); self._lockfile.flush()
                self._lockfile.seek(0); msvcrt.locking(self._lockfile.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self._lockfile.fileno(),fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self._lockfile.close()
            raise RuntimeError('This data folder is already open in another Batch Image Studio process. Close that process first, or use a different --data folder.') from None
        self.images = self.directory / 'images'; self.images.mkdir(exist_ok=True)
        self.lock = threading.RLock(); self.db = sqlite3.connect(self.directory / 'studio.sqlite3', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, value TEXT NOT NULL); CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, theme TEXT, prompt TEXT, status TEXT, error TEXT, file TEXT);')
        columns = {r[1] for r in self.db.execute('PRAGMA table_info(tasks)')}
        for name, kind in [('request_id','TEXT'),('attempts','INTEGER DEFAULT 0')]:
            if name not in columns: self.db.execute(f'ALTER TABLE tasks ADD COLUMN {name} {kind}')
        self.db.execute("UPDATE tasks SET status='unknown',error='Interrupted request; check provider billing/history before explicitly retrying.' WHERE status='running'"); self.db.commit()
        row = self.db.execute('SELECT value FROM settings WHERE id=1').fetchone()
        self.project = json.loads(row['value']) if row else None
        self.db.execute('CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, name TEXT, endpoint TEXT)')
        self.db.execute('INSERT OR IGNORE INTO profiles VALUES(?,?,?)',('openai','OpenAI',DEFAULT_ENDPOINT)); self.db.commit()
        self.keys = {}; self.key = ''; self.endpoint = DEFAULT_ENDPOINT; self.running = False; self.paused = False; self.sample = False
        self.stop = threading.Event(); self.wake = threading.Event(); self.demo_delay = demo_delay
        self.generation = 0
        self.worker = threading.Thread(target=self._worker, daemon=True); self.worker.start()

    def close(self):
        self.stop.set(); self.wake.set(); self.worker.join(timeout=125)
        if self.worker.is_alive():
            raise RuntimeError('An image request is still in flight. The data-folder lock remains held until this process exits.')
        with self.lock:
            self.db.close(); self.key = ''; self.keys.clear()
            if os.name == 'nt':
                import msvcrt
                self._lockfile.seek(0); msvcrt.locking(self._lockfile.fileno(),msvcrt.LK_UNLCK,1)
            self._lockfile.close()

    def configure(self, data):
        endpoint = str(data.get('endpoint') or DEFAULT_ENDPOINT).strip()
        parsed = urllib.parse.urlsplit(endpoint)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment or parsed.query:
            raise ValueError('Endpoint must be an HTTPS URL without credentials, query, or fragment.')
        if endpoint != DEFAULT_ENDPOINT and data.get('explicitConfirm') is not True:
            raise ValueError('A custom endpoint receives your API key and prompts. Explicit confirmation is required.')
        provider_id = str(data.get('providerId') or 'openai')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',provider_id): raise ValueError('Invalid provider ID.')
        name = str(data.get('name') or provider_id)[:100]
        key = str(data.get('key', '')).strip()
        if len(key) > 4096 or '\n' in key or '\r' in key: raise ValueError('Invalid API key.')
        with self.lock:
            if self.running or self.db.execute("SELECT 1 FROM tasks WHERE status='running'").fetchone(): raise ValueError('Wait for the active request to finish before changing API settings.')
            previous = self.db.execute('SELECT endpoint FROM profiles WHERE id=?',(provider_id,)).fetchone()
            if previous and previous['endpoint'] != endpoint: self.keys.pop(provider_id,None)
            self.keys[provider_id] = key
            self.db.execute('INSERT OR REPLACE INTO profiles VALUES(?,?,?)',(provider_id,name,endpoint)); self.db.commit()
            self.key = key; self.endpoint = endpoint
        return self.state()

    def create_project(self, data):
        style = str(data.get('style', '')).strip()
        themes = data.get('themes', [])
        if isinstance(themes, str): themes = themes.splitlines()
        if not isinstance(themes, list): raise ValueError('Themes must be a list or one theme per line.')
        themes = [str(t).strip() for t in themes if str(t).strip()]
        count = int(data.get('per_theme',data.get('count',1))); rpm = float(data.get('rpm', 6))
        if not themes or len(themes) > 1000 or any(len(t) > 5000 for t in themes): raise ValueError('Enter 1–1000 themes, each at most 5000 characters.')
        if not 1 <= count <= 2000 or count * len(themes) > 2000: raise ValueError('Each theme needs at least one image; total cannot exceed 2000.')
        if not 1 <= rpm <= 60: raise ValueError('Requests per minute must be between 1 and 60.')
        if len(style) > 20000: raise ValueError('Style is too long.')
        mode = data.get('mode', 'demo')
        if mode not in ('demo', 'openai'): raise ValueError('Mode must be demo or openai.')
        model = str(data.get('model') or 'gpt-image-1.5')
        size = str(data.get('size') or '1024x1024'); quality = str(data.get('quality') or 'medium')
        if len(model) > 100 or size not in ('auto','1024x1024','1536x1024','1024x1536') or quality not in ('auto','low','medium','high'): raise ValueError('Invalid model, size, or quality.')
        provider_id = str(data.get('providerId') or 'openai')
        with self.lock: profile = self.db.execute('SELECT endpoint FROM profiles WHERE id=?',(provider_id,)).fetchone()
        if not profile: raise ValueError('Configure this provider first.')
        prompts = data.get('prompts')
        total = count * len(themes)
        if prompts is not None and (not isinstance(prompts,list) or len(prompts) != total or any(not isinstance(p,str) or not p.strip() or len(p)>30000 for p in prompts)): raise ValueError('Provide one nonempty prompt per task, at most 30000 characters each.')
        project = dict(name=str(data.get('name') or 'Untitled project')[:200],style=style, themes=themes, count=count, per_theme=count, total=total, rpm=rpm, mode=mode, model=model, size=size, quality=quality,providerId=provider_id,endpoint=profile['endpoint'])
        with self.lock:
            if self.running or self.db.execute("SELECT 1 FROM tasks WHERE status='running'").fetchone(): raise ValueError('Stop and wait for the active request before replacing the project.')
            self.generation += 1; self.paused = False; self.project = project
            self.db.execute('DELETE FROM tasks')
            for i in range(total):
                theme = themes[i // count]
                prompt = prompts[i] if prompts is not None else f'{style}\n\nSubject / theme: {theme}\nVariation: {i % count + 1}'.strip()
                self.db.execute('INSERT INTO tasks(theme,prompt,status,error,file) VALUES(?,?,?,?,?)', (theme,prompt,'pending','',''))
            self.db.execute('INSERT OR REPLACE INTO settings VALUES(1,?)', (json.dumps(project),)); self.db.commit()
        return self.state()

    def state(self):
        with self.lock:
            tasks = [dict(r) for r in self.db.execute('SELECT * FROM tasks ORDER BY id')]
            counts = dict(pending=0,running=0,completed=0,failed=0,cancelled=0,unknown=0)
            for t in tasks:
                counts[t['status']] += 1; t['image_url'] = '/images/' + str(t['id']) if t.pop('file') else None
            profiles = [dict(r) for r in self.db.execute('SELECT * FROM profiles ORDER BY id')]
            for p in profiles: p['configured'] = bool(self.keys.get(p['id']))
            return dict(project=self.project,tasks=tasks,counts=counts,running=self.running,paused=self.paused,configured=bool(self.keys.get((self.project or {}).get('providerId','openai'))),endpoint=self.endpoint,profiles=profiles)

    def control(self, action, data=None):
        data = data or {}
        with self.lock:
            if action in ('start','resume','sample'):
                if not self.project: raise ValueError('Create a project first.')
                if self.project['mode'] == 'openai':
                    provider_id = self.project.get('providerId','openai')
                    profile = self.db.execute('SELECT endpoint FROM profiles WHERE id=?',(provider_id,)).fetchone()
                    if not profile or profile['endpoint'] != self.project.get('endpoint',DEFAULT_ENDPOINT): raise ValueError('Provider endpoint changed. Create a new project to use it; existing tasks are pinned to the original endpoint.')
                    if not self.keys.get(provider_id): raise ValueError('Enter this project provider’s API key first.')
                if self.running: raise ValueError('The queue is already running.')
                self.sample = action == 'sample'; self.running = True; self.paused = False
            elif action == 'pause': self.running = False; self.paused = True
            elif action == 'cancel':
                self.running = False; self.paused = False
                self.db.execute("UPDATE tasks SET status='cancelled',error='Cancelled before sending.' WHERE status='pending'")
            elif action == 'retry':
                if self.running: raise ValueError('Pause the queue before retrying.')
                ids = data.get('ids')
                if ids is not None and (not isinstance(ids,list) or not ids or any(type(i) is not int for i in ids)): raise ValueError('Retry IDs must be a nonempty integer list.')
                where = '' if ids is None else ' AND id IN (' + ','.join('?' for _ in ids) + ')'
                params = ids or []
                if ids and self.db.execute("SELECT 1 FROM tasks WHERE status='unknown'"+where,params).fetchone() and data.get('confirmUnknown') is not True: raise ValueError('Unknown requests may already be billed. Check provider history, then confirmUnknown to retry.')
                states = "('failed','cancelled','unknown')" if data.get('confirmUnknown') is True else "('failed','cancelled')"
                self.db.execute("UPDATE tasks SET status='pending',error='',attempts=0 WHERE status IN "+states+where,params)
            else: raise ValueError('Unknown action.')
            self.db.commit(); self.wake.set()
        return self.state()

    def _worker(self):
        next_request = 0.0
        while not self.stop.is_set():
            self.wake.wait(0.1); self.wake.clear()
            with self.lock:
                if not self.running: continue
                row = self.db.execute("SELECT * FROM tasks WHERE status='pending' ORDER BY id LIMIT 1").fetchone()
                if not row: self.running = False; continue
                project = dict(self.project)
                if project['mode'] != 'demo' and time.monotonic() < next_request: continue
                task = dict(row); generation = self.generation; key = self.keys.get(project.get('providerId','openai'),''); endpoint = project.get('endpoint',DEFAULT_ENDPOINT)
                self.db.execute("UPDATE tasks SET status='running',error='',attempts=attempts+1 WHERE id=?",(task['id'],)); self.db.commit()
                next_request = time.monotonic() + 60 / project['rpm']
            content = None
            try:
                if project['mode'] == 'demo':
                    if self.stop.wait(self.demo_delay): return
                    content, extension = self._demo(task), 'svg'
                else: content, extension, request_id = self._generate(task,project,key,endpoint)
                if project['mode'] == 'demo': request_id = ''
                with self.lock:
                    if generation == self.generation:
                        filename = f"{task['id']:05d}.{extension}"
                        tmp = self.images / (filename + '.tmp'); tmp.write_bytes(content); tmp.replace(self.images / filename)
                        self.db.execute("UPDATE tasks SET status='completed',file=?,request_id=?,error='' WHERE id=?",(filename,request_id,task['id'])); self.db.commit()
            except RateLimited as exc:
                with self.lock:
                    if generation == self.generation:
                        if not self.running and not self.paused: status, message = 'cancelled', 'Cancelled after a rate-limited request.'
                        elif (task.get('attempts') or 0) >= 2:
                            status, message = 'failed', 'Rate limit retry budget exhausted; review provider limits before retrying.'
                            self.running = False; self.paused = True
                        else:
                            status, message = 'pending', 'Rate limited; retrying after bounded backoff (maximum 2 retries).'
                            next_request = max(next_request,time.monotonic()+exc.delay)
                        self.db.execute('UPDATE tasks SET status=?,error=? WHERE id=?',(status,message,task['id'])); self.db.commit()
                continue
            except Exception as exc:
                message = str(exc)
                if key: message = message.replace(key,'[redacted]')
                with self.lock:
                    if generation == self.generation:
                        status = 'unknown' if isinstance(exc,UnknownRequest) or (project['mode'] == 'openai' and content is not None) else 'failed'
                        self.db.execute("UPDATE tasks SET status=?,error=? WHERE id=?",(status,message[:600],task['id'])); self.db.commit()
                        # Fail closed: authentication, quota, policy, or network errors need review.
                        self.running = False; self.paused = True
            with self.lock:
                if self.sample: self.running = False; self.sample = False

    @staticmethod
    def _demo(task):
        title = html.escape(task['theme'][:80]); number = task['id']
        return f'''<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024"><rect width="1024" height="1024" fill="#f3eee4"/><circle cx="512" cy="410" r="230" fill="#bac8b1"/><path d="M280 600 Q512 100 744 600 M350 510 Q512 690 674 510" stroke="#263c35" stroke-width="14" fill="none"/><text x="512" y="780" text-anchor="middle" font-family="sans-serif" font-size="30">{title}</text><text x="512" y="850" text-anchor="middle" font-family="sans-serif" font-size="24">演示 SVG • {number} • NOT AI GENERATED</text></svg>'''.encode()

    @staticmethod
    def _generate(task, project, key, endpoint):
        payload = dict(model=project['model'], prompt=task['prompt'], n=1,size=project['size'],quality=project['quality'],output_format='png')
        request = urllib.request.Request(endpoint,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+key},method='POST')
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs): return None
        # Disable inherited HTTP proxies: do not silently send credentials to an unrelated proxy.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
        try:
            with opener.open(request,timeout=120) as response:
                body = response.read(40 * 1024 * 1024 + 1)
                if len(body) > 40 * 1024 * 1024: raise UnknownRequest('Successful response is too large; check provider history before retrying.')
                request_id = str(response.headers.get('x-request-id','')).replace(key,'[redacted]')[:200] if key else str(response.headers.get('x-request-id',''))[:200]
                try: result = json.loads(body)
                except (ValueError,UnicodeError): raise UnknownRequest('Successful API response was invalid JSON; check provider history before retrying.') from None
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                try:
                    error = json.loads(exc.read(65536)).get('error',{})
                    code = str(error.get('code') or error.get('type') or '').lower()
                except (ValueError,TypeError,AttributeError): code = None
                except Exception: raise UnknownRequest('Rate-limit response was interrupted; check provider history before retrying.') from None
                if code in ('rate_limit_exceeded','rate_limit_error',''):
                    retry_after = exc.headers.get('Retry-After')
                    delay = 10 * 2 ** min(task.get('attempts') or 0,2)
                    if retry_after:
                        try: delay = float(retry_after)
                        except ValueError:
                            try: delay = email.utils.parsedate_to_datetime(retry_after).timestamp() - time.time()
                            except (ValueError,TypeError,OverflowError): raise ValueError('Provider supplied an unreadable Retry-After; queue paused for manual review.') from None
                    if not math.isfinite(delay) or delay > 120: raise ValueError('Provider requested a long Retry-After; queue paused rather than retrying early. Check provider limits before resuming.')
                    delay = max(1,delay)
                    raise RateLimited(delay) from None
            error_type = UnknownRequest if exc.code >= 500 else ValueError
            raise error_type(f'Image API returned HTTP {exc.code}. Check credentials, billing, model access, and prompt; no automatic retry was made.') from None
        except UnknownRequest: raise
        except Exception: raise UnknownRequest('Image API transport or response error. Check the provider dashboard before retrying: the request may have been billed.') from None
        try: content = base64.b64decode(result['data'][0]['b64_json'],validate=True)
        except (KeyError,IndexError,ValueError,TypeError): raise UnknownRequest('API did not return a valid base64 image; URL-only responses are not downloaded.') from None
        if not content.startswith(b'\x89PNG\r\n\x1a\n'): raise UnknownRequest('API response is not the requested PNG image.')
        return content, 'png', request_id

    def image(self, task_id):
        with self.lock:
            row = self.db.execute('SELECT file FROM tasks WHERE id=? AND status=\'completed\'', (task_id,)).fetchone()
            if not row or not row['file']: raise FileNotFoundError()
            path = self.images / row['file']
            return path.read_bytes(), 'image/svg+xml' if path.suffix == '.svg' else 'image/png'

    def export(self):
        output = io.BytesIO()
        with self.lock, zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
            manifest = self.state()
            manifest.pop('configured',None); manifest.pop('endpoint',None)
            archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            project = dict(self.project or {}); project['prompts'] = [t['prompt'] for t in manifest['tasks']]
            archive.writestr('project.json',json.dumps(project,ensure_ascii=False,indent=2))
            csv_buffer = io.StringIO(newline=''); writer = csv.writer(csv_buffer)
            writer.writerow(['id','theme','prompt','status','error','request_id','attempts','filename'])
            for task in manifest['tasks']:
                filename = self.db.execute('SELECT file FROM tasks WHERE id=?',(task['id'],)).fetchone()['file']
                values = [task.get(k,'') for k in ['id','theme','prompt','status','error','request_id','attempts']] + [filename]
                writer.writerow(["'"+str(v) if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v for v in values])
            archive.writestr('tasks.csv','\ufeff'+csv_buffer.getvalue())
            for row in self.db.execute("SELECT file FROM tasks WHERE status='completed'"):
                path = self.images / row['file']
                if path.exists(): archive.write(path,'images/'+path.name)
            archive.writestr('README.txt','Original outputs; no resizing or recompression. Demo SVG files are placeholders, not AI-generated images. Prompts and task states are in manifest.json.\n')
        return output.getvalue()


def make_server(studio, static_dir, port=0, token=None):
    token = token or secrets.token_urlsafe(32)
    static_dir = Path(static_dir)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_): pass
        def reply(self, status, body, content_type='application/json'):
            if isinstance(body,(dict,list)): body=json.dumps(body,ensure_ascii=False).encode()
            if isinstance(body,str): body=body.encode()
            self.send_response(status); self.send_header('Content-Type',content_type); self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer'); self.send_header('X-Frame-Options','DENY')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'")
            if content_type == 'application/zip': self.send_header('Content-Disposition','attachment; filename="batch-images.zip"')
            self.end_headers(); self.wfile.write(body)
        def authorized(self, needs_token=True):
            expected = f'127.0.0.1:{self.server.server_port}'
            if self.headers.get('Host') != expected:
                self.reply(403,{'error':'Invalid local Host.'}); return False
            origin = self.headers.get('Origin')
            if origin and origin != 'http://' + expected:
                self.reply(403,{'error':'Cross-origin requests are not allowed.'}); return False
            if self.headers.get('Sec-Fetch-Site') == 'cross-site':
                self.reply(403,{'error':'Cross-site requests are not allowed.'}); return False
            if needs_token and not secrets.compare_digest(self.headers.get('X-Studio-Token',''),token):
                self.reply(401,{'error':'Session token required. Reload the local application.'}); return False
            return True
        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            public = path in ('/','/index.html','/manual.html','/api.html','/app.js','/styles.css','/style.css')
            if not self.authorized(not public): return
            try:
                if path in ('/','/index.html','/manual.html','/api.html'):
                    content = (static_dir/('api.html' if path == '/api.html' else 'index.html')).read_text(encoding='utf-8').replace('__SESSION_TOKEN__',token)
                    self.reply(200,content,'text/html; charset=utf-8')
                elif public:
                    self.reply(200,(static_dir/path[1:]).read_bytes(),'text/javascript; charset=utf-8' if path.endswith('.js') else 'text/css; charset=utf-8')
                elif path == '/api/state': self.reply(200,studio.state())
                elif path == '/api/export': self.reply(200,studio.export(),'application/zip')
                elif path.startswith('/images/'):
                    content,mime = studio.image(int(path.rsplit('/',1)[1])); self.reply(200,content,mime)
                else: self.reply(404,{'error':'Not found.'})
            except (FileNotFoundError,ValueError): self.reply(404,{'error':'Not found.'})
        def do_POST(self):
            if not self.authorized(): return
            try:
                if self.headers.get('Transfer-Encoding'): raise ValueError('Chunked requests are unsupported.')
                length = int(self.headers.get('Content-Length','0'))
                if not 0 < length <= MAX_BODY: raise ValueError('Request must be between 1 byte and 32 MiB. Reduce task count or prompt length.')
                if self.headers.get('Content-Type','').split(';')[0] != 'application/json': raise ValueError('JSON content type required.')
                data = json.loads(self.rfile.read(length))
                if not isinstance(data,dict): raise ValueError('JSON object required.')
                if self.path == '/api/project': result=studio.create_project(data)
                elif self.path == '/api/config': result=studio.configure(data)
                elif self.path == '/api/control': result=studio.control(data.get('action'),data)
                else: self.reply(404,{'error':'Not found.'}); return
                self.reply(200,result)
            except (ValueError,TypeError,OverflowError) as exc: self.reply(400,{'error':str(exc)[:400]})
            except Exception: self.reply(500,{'error':'Local operation failed. Check available disk space and restart if necessary.'})
    server = ThreadingHTTPServer(('127.0.0.1',port),Handler); server.daemon_threads=True
    return server


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--port',type=int,default=8765); parser.add_argument('--data',default=str(Path(__file__).parent/'data')); parser.add_argument('--no-browser',action='store_true'); args=parser.parse_args()
    try: studio=Studio(args.data)
    except RuntimeError as exc: raise SystemExit(str(exc)) from None
    try: server=make_server(studio,Path(__file__).parent,args.port)
    except OSError:
        studio.close(); raise SystemExit('Cannot start local server. Port may be occupied; try --port 8766.')
    url=f'http://127.0.0.1:{server.server_port}/'; print('Batch Image Studio: '+url+'\nKeep this window open. Ctrl+C to stop. API keys remain in memory only.')
    if not args.no_browser:
        import webbrowser
        webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); studio.close()

if __name__ == '__main__': main()
